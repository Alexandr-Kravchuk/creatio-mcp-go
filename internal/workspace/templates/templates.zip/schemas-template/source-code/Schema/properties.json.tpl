﻿{
  "Properties": {}
}